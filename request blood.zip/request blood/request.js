var btn1=document.getElementById("btn1");



var body=document.getElementsByTagName("body")[0];  
var sn='SN';
var donor='NAME';
var mobile='MOBILE';

var containerDiv;
var snDiv;
var nameDiv;
var mobDiv;

btn1.addEventListener("click", ()=>{
    donorInfo();

    sn=0;
    donor='Tanish kini';
    mobile='9370343996';
    donorInfo();

    donor='Krishi Devani';
    mobile='9857878439';
    donorInfo();

    donor='Kishan Ukani';
    mobile='8976545643';
    donorInfo();
});

function donorInfo(){

    if(sn!='SN'){ sn++; }

    document.getElementsByTagName("form")[0].style.display="none";
    console.log("hii");

    containerDiv=document.createElement("div");
    containerDiv.classList.add("container2");

    if(sn=='SN'){
        containerDiv.classList.add("new");
    }

    snDiv=document.createElement("div");
    snDiv.innerText=sn;
    snDiv.classList.add("sn");

    nameDiv=document.createElement("div");
    nameDiv.innerText=donor;
    nameDiv.classList.add("name");

    mobDiv=document.createElement("div");
    mobDiv.innerText=mobile;
    mobDiv.classList.add("mobile");

    containerDiv.appendChild(snDiv);
    containerDiv.appendChild(nameDiv);
    containerDiv.appendChild(mobDiv);

    body.appendChild(containerDiv);
}

